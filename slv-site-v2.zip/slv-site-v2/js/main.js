(function(){
var GURL='https://share.google/xiNsH5lJnU8G5jDQJ';
/* Paste real Google reviews here: {name:'Name',stars:5,text:'Review text'} */
var REVIEWS=[];
var d=document,m=d.getElementById('menu'),l=d.getElementById('links');
if(m){m.addEventListener('click',function(){m.setAttribute('aria-expanded',l.classList.toggle('open'))})}
var f=d.getElementById('enquiry');
if(f){f.addEventListener('submit',function(e){e.preventDefault();
var t='Hello SLV Online, I am '+f.name.value.trim()+'. I need help with: '+f.service.value+'.'+(f.msg.value.trim()?' '+f.msg.value.trim():'');
window.open('https://wa.me/918142881072?text='+encodeURIComponent(t),'_blank','noopener')})}
var r=d.getElementById('rev');
if(r){var list=REVIEWS.length?REVIEWS:[{cta:1}];list.forEach(function(v){var c=d.createElement('div');c.className='card';
if(v.cta){c.innerHTML='<h3>Share your experience</h3><p>Customers review us on Google. Tell others how we helped you.</p><p><a class="btn" target="_blank" rel="noopener" href="'+GURL+'">Open our Google profile</a></p>'}
else{var s=d.createElement('div');s.className='stars';s.textContent='\u2605'.repeat(v.stars||5);var p=d.createElement('p');p.textContent=v.text;var n=d.createElement('strong');n.textContent=v.name;c.append(s,p,n)}
r.appendChild(c)})}
var y=new Date().getFullYear();d.querySelectorAll('[data-years]').forEach(function(e){e.dataset.to=y-2016});
d.querySelectorAll('.yr').forEach(function(e){e.textContent=y});
var rm=matchMedia('(prefers-reduced-motion:reduce)').matches;
function count(e){var to=+e.dataset.to,s=0;if(rm){e.textContent=to;return}var i=setInterval(function(){s++;e.textContent=Math.round(to*s/30);if(s>=30)clearInterval(i)},30)}
if('IntersectionObserver' in window){d.documentElement.classList.add('js');
var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');if(x.target.dataset.to)count(x.target);io.unobserve(x.target)}})},{threshold:.15});
d.querySelectorAll('.rv,[data-to],[data-years]').forEach(function(e){io.observe(e)})}
var pb=d.querySelector('.progress');if(pb){addEventListener('scroll',function(){var h=d.documentElement;pb.style.width=(h.scrollTop/(h.scrollHeight-h.clientHeight)*100)+'%'},{passive:true})}
})();
